###USE THE PART TOWARDS THE END WITH THE NUMBERS AND NUMBERS BETWEEN###

getwd()
setwd("/Downloads")
clusterres <- read.csv("sentclusterresultsclean.csv", stringsAsFactors = F)
clusterres <- as.data.frame(clusterres[,3])

write.table(as.data.frame(clusterres[179:180,]),file = "test2.txt", row.names = F, col.names = F)


b <- read.csv("test2.txt", header = F)
b[] <- lapply(b, as.character)

l <- as.data.frame(matrix(0, ncol = 1, nrow = (nrow(b))))


for (i in 1:nrow(b)) {
  if (length(unlist(strsplit (b[i,1], " "))) > ncol(l)) {
    l <- as.data.frame(matrix(0, ncol = length(unlist(strsplit (b[i,1], " "))), nrow = (nrow(b))))
  }
  
}
n <- 1
for (i in 1:nrow(b)) {
  n <- as.numeric(as.numeric(ncol(l)) - as.numeric(length(unlist(strsplit(b[i,1], " ")))))
  l[i,] <- c(unlist(strsplit (b[i,1], " ")), rep("IGNORE", times = as.numeric(n)))
}


seq <- as.data.frame(matrix("IGNORE", ncol = ncol(l), nrow = 1), stringsAsFactors = F)

non <- as.data.frame(matrix("IGNORE", ncol = 3, nrow = ncol(l)*nrow(l)), stringsAsFactors = F)
colnames(non) <- c("word", "position", "frequency")
non$position <- rep(1, times = nrow(non))
non$frequency <- rep(1, times = nrow(non))
non[,2] <- sapply(non[,2], as.numeric)
non[,3] <- sapply(non[,3], as.numeric)

n <- 0 
p <- 1
for (i in 1:nrow(l)) {
  for (j in 1:ncol(l)) {
    if (j > 0) {
      k <- 1
      while (k <= nrow(l)) {
        if (l[i,j] == l[k,j]) {
          n <- n + 1
        }
        if (k < nrow(l)) {
          k <- k + 1
        }
        else {
          break
        }
      }
    }  
    'if (j < ncol(l)) {
      k <- 1
      while (k <= nrow(l)) {
        if (l[i,j] == l[k,j+1]) {
          n <- n + 1
        }
        if (k < nrow(l)) {
          k <- k + 1
        }
        else {
          break
        }
      }
    }
    if (j > 1) {
      k <- 1
      while (k <= nrow(l)) {
        if (l[i,j] == l[k,j-1]) {
          n <- n + 1
        }
        if (k < nrow(l)) {
          k <- k + 1
        }
        else {
          break
        }
      }
    }
    if (j < (ncol(l)-1)) {
      k <- 1
      while (k <= nrow(l)) {
        if (l[i,j] == l[k,j+2]) {
          n <- n + 1
        }
        if (k < nrow(l)) {
          k <- k + 1
        }
        else {
          break
        }
      }  
    }
    if (j > 2) {
      k <- 1
      while (k <= nrow(l)) {
        if (l[i,j] == l[k,j-2]) {
          n <- n + 1
        }
        if (k < nrow(l)) {
          k <- k + 1
        }
        else {
          break
        }
      }  
    }'
    print(n)
    if( ((n/nrow(l)) > 0.5) & l[i,j] != "IGNORE"){
      seq[1,j] <- l[i,j]
    }
    if( ((n/nrow(l)) <= 0.5) & l[i,j] != "IGNORE")   {
      non[p,1] <- l[i,j]
      non[p,2] <- j
      p <- p + 1
    }
    n <- 0
  }
} 

non <- subset(non, word != "IGNORE")

# Knock out any that don't have at least 4 in position

igvec <- c()

g <- 1
 
for (i in 1:ncol(seq)) {
  if (seq[1,i] == "IGNORE") {
    igvec[g] <- i
    g <- g + 1
  }
}

non <- cbind(non, rep("f", times = nrow(non)))
colnames(non)[4] <- "tf"
non[,4] <- sapply(non[,4], as.character)
w <-0
for (i in 1:nrow(non)) {
  for (k in 1:length(igvec)) {
    if (non[i, 2] == igvec[k]){
      w <- w + 1
    }
    if (w > 0) {
      non[i,4] <- "t"
    }
    w <- 0
  }
}
non <- subset(non, tf == "t")

n <- 0
for (i in 1:nrow(non)) {
  for (k in 1:nrow(non))
    if (non[i,2] == non[k,2]) {
      n <- n + 1  
    }
    if (n/nrow(l) < 0.5) {
      non[i, 4] <- "p"
    }
    n <- 0
}
non <- subset(non, tf != "p")

non <- non[,-4]

n <- 0
for (j in 1:ncol(seq)) {
  if (seq[1, j] == "IGNORE") {
    for (i in 1:nrow(non)) {
      if (j == non[i,2]) {
        n <- n + 1
      }
    }
    if (n == 0) {
      seq <- seq[,-j]
    }
      
  }
  n <- 0
  
}

p <- list(as.character(print(seq[1,])))
p <- as.data.frame(p)
colnames(p)[1] <- "col1"
p <- cbind(p, rep("f", times =nrow(p)))
colnames(p)[2] <- "tf"
p[,2] <- sapply(p[,2], as.character)
for (i in 1:nrow(p)) {
  if (p[i,1] == "IGNORE") {
    if (p[i,1] == p[(i-1),1])
      p[i,2] <- "t"
  }
}

p <- subset(p, tf == "f")
p <- as.character(print(p[,1]))
p <- paste(p,collapse=" ")
w <- strsplit(p, "IGNORE")
w <- as.data.frame(w[[1]])
colnames(w)[1] <- "col1"
w <- subset(w, col1 != " ")
w <- subset(w, col1 != "")
w <- as.character(w[,1])
w[1]
w[2]
w <- gsub(" ","", w)


non2 <- as.data.frame(matrix("m", ncol = ncol(l), nrow = nrow(l)), stringsAsFactors = F)

g <- 1 


for (j in 1:nrow(l)) {
  if (j > 0) {
    for (i in 1:length(w)) {
      if (i > 0) {
        for (k in 1:ncol(l)) {
          for (m in 1:ncol(l)) {
            if (w[i] == gsub(" ","",paste(l[j,k:m],collapse=" "))) {
              non2[j, g] <- paste(as.character(k),":", as.character(m))
              g <- g + 1
            }
          }
        }
      }
    }
  }
  g <- 1
}

non3 <- as.data.frame(matrix("IGNORE", ncol = ncol(l), nrow = nrow(l)), stringsAsFactors = F)

g <- 1


for (m in 1:nrow(non2)) {
  q <- as.character(print(non2[m,]))
  q <- paste(q,collapse=" ")
  q <- strsplit(q, "m")
  q <- q[[1]][1]
  q <- unlist(q)
  q <- unlist(strsplit(q, ":"))
  q <- unlist(strsplit(q, " "))
  q <- list(q)
  q <- as.data.frame(q[[1]])
  colnames(q)[1] <- "col1"
  q <- subset(q, col1 != "")
  q[,1] <- sapply(q[,1], as.character)
  q[,1] <- sapply(q[,1], as.numeric)
  i <- 1
  while (i <= nrow(q)) {
    if ((i %% 2 == 0) & (i != nrow(q))) {
      non3[m,g] <- paste(as.character(l[m,(as.numeric(q[i,1]+1)):(as.numeric(q[i+1,1]-1))]), collapse = " ")
      g <- g + 1
    }
    if (i < nrow(q)) {
      i <- i + 1
    }
    else {
      break
    }
  }
  g <- 1
}

for (i in 1:ncol(seq)) {
  if (seq[1,i] == "IGNORE") {
   seq[1,i] <- "BLANK" 
  }
}

non3 <- as.data.frame(t(non3))
non3 <- cbind(non3, rep("f", times = nrow(non3)))
colnames(non3)[ncol(non3)] <- "tf"
non3[] <- lapply(non3, as.character)

for (i in 1:nrow(non3)) {
  if (paste(as.character(print(non3[i,1:(ncol(non3)-1)])), collapse = " ") == paste(as.character(rep("IGNORE", times = ncol(non3)-1)), collapse = " ")) {
    non3[i,ncol(non3)] <- "t" 
  }
}

non3 <- subset(non3, tf == "f")  
non3 <- non3[,-(ncol(non3))]
non3 <- as.data.frame(t(non3))

seq <- as.data.frame(t(seq))
seq <- cbind(seq, rep("f", times = nrow(seq)))
colnames(seq)[ncol(seq)] <- "tf"
seq[] <- lapply(seq, as.character)

for (i in 1:nrow(seq)) {
  if (seq[i,1] == "BLANK") {
    if (seq[i,1] == seq[(i-1),1])
      seq[i,2] <- "t"
  }
}
seq <- subset(seq, tf == "f")  
seq <- as.data.frame(seq[,-(ncol(seq))])
colnames(seq)[1] <- "Template"
seq <- as.data.frame(t(seq))


template <- seq
fillins <- non3

#write.table(template, file = "template4-18.csv")
#write.table(fillins, file = "fillins4-18.csv")
