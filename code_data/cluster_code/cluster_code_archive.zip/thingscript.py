import os

f = open('./Downloads/allInclusionExclusionBulletPoint.csv')
f.readline()
counter = 0
os.chdir('./Downloads/sentfilepython2/')
for line in f:
	if counter % 25000 == 0:
		print "processing line " + str(counter)
		if counter != 0:		
			os.chdir('..')
		os.chdir(str(counter/25000))
	data = line.split(',')
	s = data[3]
	filename = 'allsent' + str(counter) + '.txt'
	counter = counter + 1
	if s.strip() != "" and s.strip() != "#NAME?" and s.strip() != "All":
		try:
			o = open(filename,'w')
			o.write(s)
			o.close()
		except Exception as e:
			print e
			continue
