'for (i in 1:nrow(ct)) {
  for (j in 1:ncol(ct)) {
ct[i,j] <- as.character(ct[i,j]) 
}

}
ct <- as.data.frame(lapply(ct, as.character))
typeof(ct[5,5])


for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (is.na(ct[i,j]))  {
ct[i,j] <- "TRUE"
}
}

}

for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (ct[i,j] == "")  {
ct[i,j] <- "TRUE"
}
}

}

for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (is.na(ct[i,j]))  {
ct[i,j] <- "TRUE"
}
}

}




for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (ct[i,j] == "TRUE" | ct[i,j] == "FALSE") {
ct[i,j] <- NA
}
}

}

realcount <- 0
nacount <- 0 
for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (!is.na(ct[i,j])) {
realcount <- realcount + 1     
}   
else {
nacount <- nacount + 1
}
}
}
realcount
nacount'






















'setwd("C:/Users/AI/Downloads")
ct <- read.csv("ctsampleinds (2).csv", header = F)



setwd("C:/Users/AI/Downloads/Cluster6")

n <- 1
for (i in 1:nrow(ct)) {
for (j in 1:ncol(ct)) {
if (!is.na(ct[i,j])) {
if (ct[i,j] != "" && ct[i,j] != "TRUE" && ct[i,j] != "FALSE") {
n <- as.character(n)
str <- paste("sent", n, ".txt", sep = "")
write.table(as.data.frame(ct[i,j]),file = str, row.names = F, col.names = F)
n <- as.numeric(n)
n <- n + 1
}
}
}
}'



'docs <- Corpus(DirSource("C:/Users/AI/Downloads/ClusterCT1"))
writeLines(as.character(docs[[25]]))

docs <- tm_map(docs,content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})
docs <- tm_map(docs, toSpace, '"')
docs <- tm_map(docs, removeWords, stopwords("english"))
docs <- tm_map(docs, stripWhitespace)
docs <- tm_map(docs,stemDocument)
dtm <- DocumentTermMatrix(docs)
m <- as.matrix(dtm)
rownames(m) <- paste(substring(rownames(m),1,3),rep("..",nrow(m)), substring(rownames(m), nchar(rownames(m))-12,nchar(rownames(m))-4))
d <- dist(m)
dmat <- as.matrix(d)
dfr <- as.data.frame(dmat)
groups <- hclust(d,method="ward.D")
plot(groups, hang=-1)


'setwd("C:/Users/AI/Downloads")
canc <- read.csv("canc.csv", header = F)

library(VIM)
aggr(canc)

set.seed(20)
clusters <- kmeans(canc, 338)'


setwd("C:/Users/AI/Downloads")
met <- read.csv("sample_output_full (1).csv", header = F)



setwd("C:/Users/AI/Downloads/MetaCluster1")

n <- 1
k <- 1
p <- 1
for (i in 1:nrow(ct)) {
  for (m in 2:nrow(met)) {
    if ((ct[i, 1]) == met[m,1]) {
      k <- m - 1
      p <- as.character(p)
      str <- paste("met", p, ".txt", sep = "")
      write.table(as.data.frame(met[n:k,]),file = str, row.names = F, col.names = F)
      n <- k + 1
      p <- as.numeric(p)
      p <- p + 1
    }
  }
}

metdocs <- Corpus(DirSource("C:/Users/AI/Downloads/MetaCluster1"))
writeLines(as.character(metdocs[[25]]))

metdocs <- tm_map(metdocs,content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})
metdocs <- tm_map(metdocs, toSpace, '"')
metdocs <- tm_map(metdocs, removeWords, stopwords("english"))
metdocs <- tm_map(metdocs, stripWhitespace)
metdocs <- tm_map(metdocs,stemDocument)
metdtm <- DocumentTermMatrix(metdocs)
metm <- as.matrix(dtm)
rownames(metm) <- paste(substring(rownames(metm),1,3),rep("..",nrow(metm)), substring(rownames(metm), nchar(rownames(metm))-12,nchar(rownames(metm))-4))
metd <- dist(metm)
metgroups <- hclust(metd,method="ward.D")
plot(metgroups, hang=-1)'

########FINAL STUFF############

library("tm")
library("SnowballC")
library("ggplot2")
library("wordcloud")




###SENTENCE###

setwd("C:/Users/AI/Downloads")
ctclnb <- read.csv("ctsampleinds_cleaned_nobool.csv", header = F)


setwd("C:/Users/AI/Downloads/ClusterSentFinal1")

n <- 1
for (i in 1:nrow(ctclnb)) {
  for (j in 1:ncol(ctclnb)) {
    if (!is.na(ctclnb[i,j])) {
      if (ctclnb[i,j] != "") {
        n <- as.character(n)
        str <- paste("sent", n, ".txt", sep = "")
        write.table(as.data.frame(ctclnb[i,j]),file = str, row.names = F, col.names = F)
        n <- as.numeric(n)
        n <- n + 1
      }
    }
  }
}


sentdocs <- Corpus(DirSource("C:/Users/AI/Downloads/ClusterSentFinal1"))
writeLines(as.character(sentdocs[[25]]))

sentdocs <- tm_map(sentdocs,content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})
sentdocs <- tm_map(sentdocs, toSpace, '"')
sentdocs <- tm_map(sentdocs, removeWords, stopwords("english"))
sentdocs <- tm_map(sentdocs, stripWhitespace)
sentdocs <- tm_map(sentdocs,stemDocument)
sentdtm <- DocumentTermMatrix(sentdocs)
sentm <- as.matrix(sentdtm)
rownames(sentm) <- paste(substring(rownames(sentm),1,3),rep("..",nrow(sentm)), substring(rownames(sentm), nchar(rownames(sentm))-12,nchar(rownames(sentm))-4))
sentd <- dist(sentm)
setwd("C:/Users/AI/Downloads")
write.csv(as.matrix(sentd), file ="distmatclustersentfinal1.csv")
sentgroups <- hclust(sentd,method="ward.D")
sentgroupsplot <- as.dendrogram(sentgroups)

plot(sentgroups, hang=-1)
par(mfrow=c(3,1))

plot(sentgroupsplot, main="Main")
plot(cut(sentgroupsplot, h=4000)$upper, 
     main="Upper tree of cut at h=1000")
plot(cut(sentgroupsplot, h=4000)$lower[[2]], 
     main="Second branch of lower tree with cut at h=3000")
library("ggplot2")
library("ggdendro")

ggdendrogram(sentgroups)
sentdata <- dendro_data(sentgroupsplot, type = "rectangle")
head(sentdata$labels)

sentdatalabel<- sentdata[["labels"]][["label"]]

sentdatalabeldf <- as.data.frame(sentdatalabel)
sentdatalabeldf <- as.data.frame(cbind(sentdatalabeldf, rep("n/a", times = nrow(sentdatalabeldf))))
gsubsen <- function(x) {gsub("sen .. ", "", x)}
sentdatalabeldf$sentdatalabel <- lapply(sentdatalabeldf$sentdatalabel, gsubsen)
setwd("C:/Users/AI/Downloads/ClusterSentFinal1")
colnames(sentdatalabeldf)[c(1,2)] <- c("file", "text")
sentdatalabeldf[] <- lapply(sentdatalabeldf, as.character)
test1 <- as.character(read.table(paste(sentdatalabeldf[1,1],".txt",sep=""), header = F)[1,1])
for (i in 1:nrow(sentdatalabeldf)) {
  sentdatalabeldf[i,2] <- as.character(read.table(paste(sentdatalabeldf[i,1],".txt",sep=""), header = F)[1,1])
  
} 

setwd("C:/Users/AI/Downloads")

write.csv(sentdatalabeldf, file = "sentclusterresultsclean.csv")

pdf("pdfgraphsentfinal2.pdf", width=40, height=15)
plot(sentgroups, hang=-1)
dev.off()

'###META###
#metam <- read.csv("sample_output_full (1).csv", header = F, stringsAsFactors = F)

###THING###
#thingtxt <- read.table("allInclusionExclusionBulletPoint.txt", fill = T)

setwd("C:/Users/AI/Downloads")

thingcsv <- read.csv("allInclusionExclusionBulletPoint.csv")

setwd("C:/Users/AI/Downloads/ClusterSentAllCTFinal1")

n <- 1
for (i in 1:nrow(thingcsv)) {
  if (!is.na(thingcsv[i,4])) {
    if (thingcsv[i,4] != "" & thingcsv[i,4] != "#NAME?" & thingcsv[i,4] != "All") {
      n <- as.character(n)
      str <- paste("allsent", n, ".txt", sep = "")
      write.table(as.data.frame(thingcsv[i,4]),file = str, row.names = F, col.names = F)
      n <- as.numeric(n)
      n <- n + 1
    }
  }
}


allsentdocs <- Corpus(DirSource("C:/Users/AI/Downloads/ClusterSentAllCTFinal1"))
writeLines(as.character(allsentdocs[[25]]))

allsentdocs <- tm_map(allsentdocs,content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})
allsentdocs <- tm_map(allsentdocs, toSpace, '"')
allsentdocs <- tm_map(allsentdocs, removeWords, stopwords("english"))
allsentdocs <- tm_map(allsentdocs, stripWhitespace)
allsentdocs <- tm_map(allsentdocs,stemDocument)
allsentdtm <- DocumentTermMatrix(allsentdocs)
allsentm <- as.matrix(allsentdtm)
rownames(allsentm) <- paste(substring(rownames(allsentm),1,3),rep("..",nrow(allsentm)), substring(rownames(allsentm), nchar(rownames(allsentm))-12,nchar(rownames(allsentm))-4))
allsentd <- dist(allsentm)
setwd("C:/Users/AI/Downloads")
write.csv(as.matrix(allsentd), file ="distmatclusterallsentfinal1.csv")
allsentgroups <- hclust(allsentd,method="ward.D")
allsentgroupsplot <- as.dendrogram(allsentgroups)

plot(allsentgroups, hang=-1)
par(mfrow=c(3,1))

plot(allsentgroupsplot, main="Main")
plot(cut(allsentgroupsplot, h=4000)$upper, 
     main="Upper tree of cut at h=1000")
plot(cut(allsentgroupsplot, h=4000)$lower[[2]], 
     main="Second branch of lower tree with cut at h=3000")
library("ggplot2")
library("ggdendro")

ggdendrogram(allsentgroups)
allsentdata <- dendro_data(allsentgroupsplot, type = "rectangle")
head(allsentdata$labels)

allsentdatalabel<- allsentdata[["labels"]][["label"]]

allsentdatalabeldf <- as.data.frame(allsentdatalabel)
allsentdatalabeldf <- as.data.frame(cbind(allsentdatalabeldf, rep("n/a", times = nrow(allsentdatalabeldf))))
gsuballsen <- function(x) {gsub("all .. ", "", x)} #this might not be right
allsentdatalabeldf$allsentdatalabel <- lapply(allsentdatalabeldf$allsentdatalabel, gsuballsen)
setwd("C:/Users/AI/Downloads/ClusterSentAllCTFinal1")
colnames(allsentdatalabeldf)[c(1,2)] <- c("file", "text")
allsentdatalabeldf[] <- lapply(allsentdatalabeldf, as.character)
for (i in 1:nrow(allsentdatalabeldf)) {
  allsentdatalabeldf[i,2] <- as.character(read.table(paste(allsentdatalabeldf[i,1],".txt",sep=""), header = F)[1,1])
  
} 

setwd("C:/Users/AI/Downloads")

write.csv(allsentdatalabeldf, file = "allsentclusterresultsclean.csv")


pdf("pdfgraphallsentfinal2.pdf", width=40, height=15)
plot(allsentgroups, hang=-1)
dev.off()'


