
setwd("/Downloads")

thingcsv <- read.csv("allInclusionExclusionBulletPoint.csv", encoding = "latin1")
thingcsv <- as.data.frame(thingcsv[,4])
thingcsv[] <- lapply(thingcsv, as.character)
Encoding(thingcsv[,1]) <- "latin1"
thingcsv[,1] <- replace_non_ascii(thingcsv[,1], remove.nonconverted = FALSE)
setwd("/Downloads/ClusterSentAllCTFinal4")

n <- 1
for (i in 1:nrow(thingcsv)) {
  if (!is.na(thingcsv[i,1]) & (thingcsv[i,1] != "" & thingcsv[i,1] != "#NAME?" & thingcsv[i,1] != "All")) {
    n <- as.character(n)
    str <- paste("allsent", n, ".txt", sep = "")
    write.table(as.data.frame(thingcsv[i,1]),file = str, row.names = F, col.names = F)
    n <- as.numeric(n)
    n <- n + 1
  }
}


# change to TRUE when u ant it to run
if (TRUE) {
  n <- 1
  for (i in 1:nrow(thingcsv)) {
    tryCatch(
      {
        if (!is.na(thingcsv[i,1])) {
          if (thingcsv[i,1] != "" & thingcsv[i,1] != "#NAME?" & thingcsv[i,1] != "All") {
            n <- as.character(n)
            str <- paste("allsent", n, ".txt", sep = "")
            write.table(as.data.frame(thingcsv[i,1]),file = str, row.names = F, col.names = F)
            n <- as.numeric(n)
            n <- n + 1
          }
        }
      },
      error=function(cond) {
        message("Here's the original error message:")
        message(cond)
      }
    )
  }
}